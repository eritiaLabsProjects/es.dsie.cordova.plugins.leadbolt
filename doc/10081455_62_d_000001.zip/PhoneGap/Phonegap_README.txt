READ ME - LeadBolt Android Cordova Phonegap library

Version 1.0      date: 2013-11-07
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow Phonegap users on Android to include the LeadBolt SDK within their Applications.

Requirements
------------

1. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

2. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

3. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.00 and above) LeadBolt android publisher SDK.


Integration
------------
The following steps need to be followed in the ADT IDE or Eclipse

1. Unzip and copy the LeadBolt Android SDK into the "libs" folder of your project. This should be the <yoursdkpackagename>.jar file

2. Copy the LeadBolt Android Phonegap Plugin into the "libs" folder of your project. This should be the LeadBoltPhonegap.jar file found in the downloaded SDK zip file.

3. Edit the config.xml (found in res/xml folder of your Android Project). Add the following lines along with the other features already defined there:
	<feature name="AdController">
		<param name="android-package" value="com.leadbolt.phonegap.android.LBPhonegapPlugin" />
	</feature>

4. In the config.xml file, please make sure <access> tag is set to the following, otherwise the SDK may not be able to track events properly:
	<access origin="*" />

5. In your App's AndroidManifest.xml file add the following permissions:
    
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    
    <!-- Optional Permissions to add -->
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_LOCATION_EXTRA_COMMANDS"/>

    <!-- Permissions Required if you are using App Re-Engagements -->
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

6. For App Re-Engagements, please add the following lines of code inside the <application> tag in your AndroidManifest.xml file:
    
    <service android:name="com.<sdkpackagename>.ReEngagementService"></service>
    <receiver android:name="com.<sdkpackagename>.ReEngagement" />
    <service android:name="com.<sdkpackagename>.AdBootReceiverService" />
    <receiver android:name="<YOUR_APP_PACKAGE_NAME>.BootReceiver">
        <intent-filter>
            <action android:name="android.intent.action.BOOT_COMPLETED" />
        </intent-filter>
    </receiver>

7. Use the following code to ensure you can re-engage users after device reboot. Add a new Class to your Project in Eclipse and name it BootReceiver.java and add the following code in there:

    import android.content.Context;
    import android.content.Intent;
    import com.<sdkpackagename>.AdBootReceiver;
    public class BootReceiver extends AdBootReceiver
    {
        public void onReceive(Context ctx, Intent intent)
        {
            intent.putExtra("sectionid", "YOUR_LB_REENGAGEMENT_ID");
            super.onReceive(ctx, intent);
            
            // Other App specific code here
        }
    }

8. Copy AdController.js file into the assets/js folder of your App and add the following script tag in your HTML code:
    <script type="text/javascript" src="js/AdController.js"></script>

9. Now in your index.html file add the following line:

	document.addEventListener('deviceready', function() {
		loadLeadBolt();
	}, false);

    function loadLeadBolt()
    {
        AdController.loadAd("YOUR_LB_SECTION_ID");

        // to load an Audio Ad
        AdController.loadAudioAd("YOUR_LB_AUDIO_ID");

        // to load an Audio Track
        AdController.loadAudioTrack("YOUR_LB_AUDIO_ID", 2);

        // to load an App Re-Engagement
        AdController.loadReEngagement("YOUR_LB_REENGAGEMENT_ID");

        // to load a Quick Start Ad
        AdController.loadStartAd("YOUR_LB_SECTION_ID", "YOUR_LB_AUDIO_ID", "YOUR_LB_REENGAGEMENT_ID");
    }

10. To Destroy Ad add the following line to your code
    AdController.destroyAd();

11. Display Ad Advanced Option - To cache an Audio Ad, call the following line of code in your JavaScript code at the start of your App.
    AdController.loadAdToCache("YOUR_LB_SECTION_ID");

    Then simply, at a specific point in your App, call this line of JavaScript:  AdController.displayAd();
    
12. Audio Ad Advanced Option - To cache an Audio Ad, call the following line of code in your JavaScript code at the start of your App.
    AdController.loadAdToCache("YOUR_LB_AUDIO_ID");

    Then simply, at the specific point in your App, call this line of JavaScript:  AdController.playAudioAd();


Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.