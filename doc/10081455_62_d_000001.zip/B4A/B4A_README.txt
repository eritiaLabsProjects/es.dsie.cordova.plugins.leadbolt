READ ME - LeadBolt Basic4Android library

Version 2.0      date: 2013-11-107
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow basic4android users to include the leadbolt publisher sdk within their basic4android applications.

Requirements
------------

1. You must have a basic4android account that allows inclusion of 3rd party libraries (http://www.basic4ppc.com)

2. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

3. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

4. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.00 and above) LeadBolt android publisher SDK.


Integration
------------
The following needs to be completed in the basic4android IDE


1. Copy the LeadBoltB4A.jar, LeadBoltB4A.xml and your SDK xml file (found in the B4A folder of the downloaded zip file) into your B4A libs folder

2. Copy LeadBolt SDK jar file which you get from above step 4 to the same folder as above one.

3. In the Basic4Android IDE, add references to your LeadBolt SDK jar file and LeadBoltB4A.jar file in your project.

4. Add the relevant code to display LeadBolt ads within your app. Following is the typical code for adding ads to your Basic4Android project:


'Activity module
Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Dim ad As LeadboltB4A
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("Main")
	
	'for all ad types
	ad.Initialize("YOUR_LB_SECTION_ID")

	'To run LeadBolt Display Ad
	ad.loadAd()

	'To run LeadBolt Display Ad - by Pre-Caching
	ad.loadAdToCache()
	' Using this will cause the Leadbolt_AdCached Sub to be triggered when successfully cached

	'To run LeadBolt Audio Ad
	'ad.loadAudioAd()

	'To run LeadBolt Audio Ad - by Pre-Caching
	'ad.loadAudioAdToCache()
	' Using this will cause the Leadbolt_AudioAdCached Sub to be triggered when successfully cached	

	'To run LeadBolt Audio Tracks
	'ad.loadAudioTrack(2)

	'To run LeadBolt Re-Engagements
	'ad.loadReEngagement()

	'To run LeadBolt Quick Start Ads
	'ad.loadStartAd("YOUR_LB_AUDIO_ID", "YOUR_LB_REENGAGEMENT_ID") 
	
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)
	
End Sub

4. To implement the appropriate Event Listeners, implement the following Sub in your Project

'Event Listeners for Display Ads
Sub Leadbolt_AdClicked

End Sub

Sub Leadbolt_AdClosed

End Sub

Sub Leadbolt_AdCompleted

End Sub

Sub Leadbolt_AdFailed

End Sub

Sub Leadbolt_AdLoaded

End Sub

Sub Leadbolt_AdCached

	'If ad.loadAdToCache() used, add the following line here -> ad.loadAd()

End Sub

Sub Leadbolt_AdProgress

End Sub

Sub Leadbolt_AdAlreadyCompleted

End Sub

Sub Leadbolt_AdPaused

End Sub

Sub Leadbolt_AdResumed

End Sub

'Event Listeners for Audio Ads
Sub Leadbolt_AudioAdProgress

End Sub

Sub Leadbolt_AudioAdClicked

End Sub

Sub Leadbolt_AudioAdClosed

End Sub

Sub Leadbolt_AudioAdFinished

End Sub

Sub Leadbolt_AudioAdFailed

End Sub

Sub Leadbolt_AudioAdLoaded

End Sub

Sub Leadbolt_AudioAdCached

	'If ad.loadAudioAdToCache() used, add the following line here -> ad.loadAudioAd()

End Sub
        

5. Open Manifest Editor in B4A by clicking "Project->Manifest Editor".

6. In the AddManifestTest block add the following permissions:
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
	<uses-permission android:name="android.permission.INTERNET"/>

7. Optional Permissions are:
	<uses-permission android:name="android.permission.READ_PHONE_STATE"/>
	<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
	<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
	<uses-permission android:name="android.permission.ACCESS_LOCATION_EXTRA_COMMANDS"/>

8. Permissions for Re-Engagements:
	<uses-permission android:name="android.permission.WAKE_LOCK" />
	<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

9. If using Re-Engagements, please add the following Receivers and Services inside the AddApplicationText block.
	<receiver android:name="com.<sdkpackagename>.ReEngagement" />
	<service android:name="com.<sdkpackagename>.ReEngagementService" />

10. In the code above, please make sure you replace the <sdkpackagename> with the actual name of your Package that is generated in the Publisher Portal.
	
11. Run your application in the Basic4Android emulator to check you see LeadBolt test ads.


Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.