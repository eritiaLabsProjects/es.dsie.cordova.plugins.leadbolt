READ ME - LeadBolt Android Cocos2d-X library

Version 1.0      date: 2013-11-07
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow Cocos2d-X users on Android to include the LeadBolt SDK within their Applications.

Requirements
------------

1. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

2. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

3. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.1 and above) LeadBolt Android publisher SDK.

Integration
------------

1. Unzip and copy the LeadBolt Android SDK and Cocos2d-X Plugin jar files into your Android project via Eclipse (found in the proj.android folder of your Cocos2d-X App).

2. In your "Classes" folder on your Cocos2d-X include the LeadboltAdWrapper.h and LeadboltAdWrapperAndroid.cpp files.

3. Open the proj.android folder in Eclipse and in your projects .java file (E.g. HelloCpp.java), inside the onCreate() method add the following line. Without this line, LeadBolt Ads may not work correctly:

	import com.leadbolt.cocos2dx.android.LeadboltAdWrapper;
	...
	...

	public class HelloCpp extends Cocos2dxActivity
	{
		...
		...
		...
		@Override
		protected void onCreate(Bundle savedInstanceState)
		{
			super.onCreate(savedInstanceState);
			...
			...
			...
			LeadboltAdWrapper.setActivity(this);
			...
			...
			...
		}
		...
		...
		...
	}

4. In your project's AndroidManifest.xml file, add the following required permissions:

	<uses-permission android:name="android.permission.INTERNET"/>
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
	

 	<!-- Optional Permissions are: -->
	<uses-permission android:name="android.permission.READ_PHONE_STATE"/>
	<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
	<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
	<uses-permission android:name="android.permission.ACCESS_LOCATION_EXTRA_COMMANDS"/>

	<!-- Permissions needed if using Re-Engagements -->
	<uses-permission android:name="android.permission.WAKE_LOCK" />
	<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

5. Add the following receivers and Services in the Manifest file before the </application> tag

	<!-- Required for LeadBolt Re-Engagements -->
	<receiver android:name="com.<sdkpackagename>.ReEngagement" />
	<service android:name="com.<sdkpackagename>.ReEngagementService" />
	<service android:name="com.<sdkpackagename>.AdBootReceiverService" />

6. In your Apps .cpp file, add the following code to implement LeadBolt Ads.

	#include "LeadboltAdWrapper.h"

	#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	
	#include "platform/android/jni/JniHelper.h"
	#include <jni.h>
	#include <string.h>

	#endif
	...
	...
	...
	// In the init method display the LeadBolt Ad
	bool HelloWorld::init()
	{
		...
		...
		...
		// LeadBolt Android Block
	#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

		// LeadBolt Quick Start Ad
		LeadboltAdWrapper::loadStartAd(lbAppAdId, lbAudioId, lbReEngamentId);

		// LeadBolt Display Ad
		LeadboltAdWrapper::loadAd("YOUR_LB_SECTION_ID");

		// For LeadBolt Audio Ad
		// LeadboltAdWrapper::loadAudioAd("YOUR_LB_AUDIO_ID");

		// For LeadBolt Audio Track
		// LeadboltAdWrapper::loadAudioAd("YOUR_LB_AUDIO_ID", 2); // 2 is the value in mins, adjust this value to your Apps needs		

		// For LeadBolt Re-Engagement
		// LeadboltAdWrapper::loadReEngagement("YOUR_LB_SECTION_ID");

	#endif

		...
		...
		...
	}

7. If everything is done correctly, you should see a LeadBolt test ad.


Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.