READ ME - LeadBolt Unity3D library

Version 2.0      updated: 2013-11-07
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow Unity3D users to include the LeadBolt publisher sdk within their Unity3D applications.

Requirements
------------

1. You must have an Unity3D account that allows inclusion of 3rd party Plugins

2. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

3. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

4. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.00 and above) LeadBolt android publisher SDK.


Integration
------------
The following needs to be completed before opening the Unity3D IDE

1. In your Unity3D workspace folder, first check if the "Assets->Plugins->Android" folders exist. If they dont then please create this path first.

2. Copy the LeadBolyUnity.jar provided in the downloaded SDK zip file to the "Assets->Plugins->Android" folder of your Project.

3. Copy the LeadBolt SDK jar file into the "Assets->Plugins->Android" folder.


The following needs to be completed in the Unity3D IDE

1. Add the relevant C# code for displaying/loading LeadBolt Ads. In your C# code where you want the LeadBolt Ad to display, add the following code:

AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"); 
AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");					
using(AndroidJavaObject ad = new AndroidJavaObject("com.unity.wrapper.LeadBoltUnity", jo))
{
	ad.Call("loadAd", "YOUR_LB_SECTION_ID");

	// for Quick Start Ads
	// ad.Call("loadStartAd", "YOUR_LB_DISPLAY_AD_ID", "YOUR_LB_AUDIO_ID", "YOUR_LB_REENGAGEMENT_ID");

	// for Re-Engagement
	// ad.Call("loadReEngagement", "YOUR_LB_REENGAGEMENT_ID");

	// for Audio Ad
	// ad.Call("loadAudioAd", "YOUR_LB_SECTION_ID");

	// for Audio Track
	// ad.Call("loadAudioTrack", "YOUR_LB_SECTION_ID", 2);
}

2. To hide/remove LeadBolt Ad from your scene, add the following C# code:
	ad.Call("destroyAd");

3. Need to add permissions in your AndroidManifest.xml file. For your Android Project, you will have a AndroidManifest.xml file in your "Assets->Plugins->Android" folder. In there add the following permissions

	<uses-permission android:name="android.permission.INTERNET"/>
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
	
	<!-- Optional Permissions -->
	<uses-permission android:name="android.permission.READ_PHONE_STATE"/>
	<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
	<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
	<uses-permission android:name="android.permission.ACCESS_LOCATION_EXTRA_COMMANDS"/>

4. Permissions for Re-Engagements:
	<uses-permission android:name="android.permission.WAKE_LOCK" />
	<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

5. Add the following receivers and Services in the Manifest file before the </application> tag

	<!-- Required for LeadBolt Re-Engagements -->
	<receiver android:name="com.<sdkpackagename>.ReEngagement" />
	<service android:name="com.<sdkpackagename>.ReEngagementService" />
	<service android:name="com.<sdkpackagename>.AdBootReceiverService" />

6. In the AndroidManifest.xml file, inside the <activity android:name="com.unity3d.player.UnityPlayerProxyActivity" ....> tab, add the following line:
	<meta-data android:name="unityplayer.ForwardNativeEventsToDalvik" android:value="true" /> 

	Please note: This line must be put just before the </activity>

7. In the code above, please make sure you replace the <sdkpackagename> with the actual name of your Package that is generated in the Publisher Portal.

8. Build and Run your application from the Unity3D IDE to check you see LeadBolt ads.

Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.